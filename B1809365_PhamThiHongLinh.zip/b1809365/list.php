<!DOCTYPE html>
<html>
<head>
	<style>
		.error {color :#FF0000;}
	</style>
</head>
<body>
<?php
	#Ham ket noi CSDL POSTGRES
	function pg_connection_string_from_database_url(){
		extract(parse_url($_ENV["DATABASE_URL"]));
		return "user=$user password=$pass host=$host dbname=".substr($path,1);
	}
	$db = pg_connect(pg_connection_string_from_database_url());
	if(!$db){
		echo "LOI: Khong the ket noi CSDL";
	}
	else{
		echo "Da mo CSDL thanh cong<br>";
	}
	#CAU LENH TRUY VAN: SELECT
	$sql = "SELECT *FROM hsdtb1809365";
	$ret = pg_query($db,$sql);
	if(!$ret){
		echo pg_last_error($db);
		exit();
	}
?>
<table border="1" cellspacing="7" cellpadding="7">
	<tr>
		<td>ID</td>
		<td>MA</td>
		<td>HO TEN</td>
		<td>LOAI</td>
		<td>DIA CHI</td>
	</tr>
<?php
	while($myrow=pg_fetch_assoc($ret)){
		printf("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
		$myrow['id'],$myrow['ma'],$myrow['hoten'],$myrow['loai'],$myrow['diachi']);
	}
	#Dong ket noi CSDL
	pg_close($db);
?>	
</table>
<br><a href='index.php'>HOME</a>
</body>
</html>

