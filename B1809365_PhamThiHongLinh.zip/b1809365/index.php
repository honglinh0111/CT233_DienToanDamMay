<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p> Ho Ten: Pham Thi Hong Linh</p>
<p> MSSV: B1809365</p>
<a href="createdb.php">Tao bang HO SO DICH TE</a><br>
<a href="add.php">Them du lieu vao form</a><br>
<a href="list.php">Xem danh sach </a><br>
</body>
</html>
