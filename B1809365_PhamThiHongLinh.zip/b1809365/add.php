<!DOCTYPE html>
<html>
<head>
	<style>
		.error {color :#FF0000;}
	</style>
</head>
<body>
<p>Them du lieu</p>
<form method="post" action="<?php echo htmlspecialchars($_SERVERT["PHP_SELF"]); ?>">
Ma: <input type="text" name="ma" value="<?php echo $ma;?>" <br>
Ho Ten: <input type="text" name="hoten" value="<?php echo $hoten;?>" <br>
Tuoi: <input type="text" name="loai" value="<?php echo $loai;?>" <br>
Dia chi: <input type="text" name="diachi" value="<?php echo $diachi;?>" <br>
<input type="submit" value="SUBMIT">
</form>
<?php
	$ma = $_POST["ma"];
	$name = $_POST["hoten"];
	$loai = $_POST["loai"];
	$addr = $_POST["diachi"];
	#Ham ket noi CSDL POSTGRES
	function pg_connection_string_from_database_url(){
		extract(parse_url($_ENV["DATABASE_URL"]));
		return "user=$user password=$pass host=$host dbname=".substr($path,1);
	}
	$db = pg_connect(pg_connection_string_from_database_url());
	if(!$db){
		echo "LOI: Khong the ket noi CSDL";
	}
	else{
		echo "Da mo CSDL thanh cong<br>";
	}
	#CAU TRUY VAN: INSERT DU LIEU
	if($ma!=null && $name!=null && $loai!=null && $addr!=null){
		$sql="INSERT INTO hsdtb1809365(ma,hoten,loai,diaChi) VALUES ('$ma','$name','$loai','$addr')";
		$ret = pg_query($db,$sql);
		if(!$ret){
			echo pg_last_error($db);
		}else{
			echo "Them du lieu thanh cong";
		}
	}
	#Dong ket noi CSDL
	pg_close($db);
?>
<br><a href='index.php'>HOME</a>
</body>
</html>

