<?php
	#Ham ket noi CSDL POSTGRES
	function pg_connection_string_from_database_url(){
		extract(parse_url($_ENV["DATABASE_URL"]));
		return "user=$user password=$pass host=$host dbname=".substr($path,1);
	}
	$db = pg_connect(pg_connection_string_from_database_url());
	if(!$db){
		echo "LOI: Khong the ket noi CSDL";
	}
	else{
		echo "Da mo CSDL thanh cong<br>";
	}
	#CAU LENH TRUY VAN: TAO BANG
	$sql = "CREATE TABLE hsdtb1809365(
	   ID SERIAL PRIMARY KEY ,
	   ma VARCHAR(50) NOT NULL,
	   hoten VARCHAR(50) NOT NULL,
	   loai VARCHAR(50) NOT NULL,
	   diaChi VARCHAR(100) NOT NULL
	)";
	# print "$sql";
	$ret = pg_query($db,$sql);
	if(!$ret){
		echo pg_last_error($db);
	}
	else{
		echo "Da tao bang thanh cong";
	}
	#Dong ket noi CSDL
	pg_close($db);
	echo "<a href='index.php'>HOME</a>";
?>
